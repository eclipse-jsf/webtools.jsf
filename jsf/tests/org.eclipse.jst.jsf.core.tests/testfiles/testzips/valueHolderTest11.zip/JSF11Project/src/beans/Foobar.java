package beans;

public class Foobar {

}
