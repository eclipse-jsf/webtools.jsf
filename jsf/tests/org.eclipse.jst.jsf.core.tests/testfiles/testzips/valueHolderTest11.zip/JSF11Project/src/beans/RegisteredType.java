package beans;

public class RegisteredType {

}
