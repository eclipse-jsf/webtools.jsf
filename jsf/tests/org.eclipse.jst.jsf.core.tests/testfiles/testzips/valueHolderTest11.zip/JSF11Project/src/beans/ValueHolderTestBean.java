package beans;


import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

public class ValueHolderTestBean {
	private java.util.Date		_date;
	private Object _object;
	private int		_integer = -1;
	private Foobar  _foobar = new Foobar();

	public java.util.Date getDate() {
		if (_date == null)
		{
			_date = new  Date();
		}
		return _date;
	}

	public void setDate(java.util.Date _date) {
		this._date = _date;
	}

	public Object getObject()
	{
		if (_object == null)
		{
			_object = new Object();
		}
		return _object;
	}
	
	public void setObject(Object object)
	{
		_object = object;
	}
	
	public int getInteger()
	{
		return _integer;
	}
	
	public void setInteger(int i)
	{
		_integer = i;
	}
	public Foobar getFoobar() {
		return _foobar;
	}

	public void setFoobar(Foobar foobar)
	{
		_foobar = foobar;
	}
	
	public char getCharacter()
	{
		return '.';
	}
	
	public void setCharacter(char value)
	{
		
	}
	
	public BigInteger getBigInteger()
	{
		return BigInteger.ONE;
	}
	
	public void setBigInteger(final BigInteger b)
	{

	}
	
	public BigDecimal getBigDecimal()
	{
		return BigDecimal.ONE;
	}
	
	public void setBigDecimal(final BigDecimal b)
	{
		
	}
	
	public RegisteredType getRegisteredType()
	{
		return new RegisteredType();
	}
	
	public void setRegisteredType(final RegisteredType registeredType)
	{
		
	}
	
	public boolean getBoolean()
	{
		return true;
	}
	
	public void setBoolean(boolean b)
	{
		
	}
	
	public byte getByte()
	{
		return 0;
	}
	
	public void setByte(final byte b)
	{
		
	}
	
	public double getDouble()
	{
		return 0.0;
	}
	
	public void setDouble(double d)
	{
		
	}
	
	public float getFloat()
	{
		return 0.0f;
	}
	
	public void setFloat(float f)
	{
		
	}
	public long getLong()
	{
		return -1;
	}
	
	public void setLong(long l)
	{
		
	}
	public short getShort()
	{
		return -1;
	}
	public void setShort(short s)
	{
		
	}
	
	public String action()
	{
		return "login";
	}
}
