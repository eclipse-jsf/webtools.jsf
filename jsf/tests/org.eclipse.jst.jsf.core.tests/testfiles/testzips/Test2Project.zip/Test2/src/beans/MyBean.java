package beans;

import java.util.HashMap;

public class MyBean {
	
	private HashMap<String, Object> myMap;
	private HashMap<String, MyBean2> myMap2;
	public HashMap<String, MyBean2> getMyMap2() {
		return myMap2;
	}

	public void setMyMap2(HashMap<String, MyBean2> myMap2) {
		this.myMap2 = myMap2;
	}

	public HashMap<String, Object> getMyMap() {
		return myMap;
	}

	public void setMyMap(HashMap<String, Object> myMap) {
		this.myMap = myMap;
	}

}
