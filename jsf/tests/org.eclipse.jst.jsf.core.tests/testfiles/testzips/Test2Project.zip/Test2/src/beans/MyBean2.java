package beans;

import java.util.List;

public class MyBean2 {
	private Boolean bool;
	
	public Boolean getBool() {
		return bool;
	}

	public void setBool(Boolean bool) {
		this.bool = bool;
	}
	public String myAction() {
		return "";
	}
	private List<MyBean3> myList;
	public List<MyBean3> getMyList() {
		return myList;
	}

	public void setMyList(List<MyBean3> myList) {
		this.myList = myList;
	}
}
