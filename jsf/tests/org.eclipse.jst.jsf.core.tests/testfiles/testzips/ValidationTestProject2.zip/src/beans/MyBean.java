package beans;

public class MyBean {
	private String readOnlyString;

	public String getReadOnlyString() {
		return readOnlyString;
	}
}
