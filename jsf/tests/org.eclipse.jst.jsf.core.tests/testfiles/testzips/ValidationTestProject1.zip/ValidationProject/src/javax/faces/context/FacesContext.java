package javax.faces.context;

import java.util.ArrayList;

/**
 * This is a fake class stub so that validation turns up an instance of FacesContext.
 * @author cbateman
 *
 */
public class FacesContext {
	public java.util.Iterator getClientIdsWithMessages()
	{
		return new ArrayList().iterator();
	}
}
