package beans;


public class MyBean3 {
	private Boolean bool;
	
	public Boolean getBool() {
		return bool;
	}

	public void setBool(Boolean bool) {
		this.bool = bool;
	}

	public String myAction() {
		return "";
	}
}
