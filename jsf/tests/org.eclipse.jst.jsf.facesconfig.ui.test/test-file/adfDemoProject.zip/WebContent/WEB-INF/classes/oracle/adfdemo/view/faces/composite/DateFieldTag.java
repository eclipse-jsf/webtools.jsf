package oracle.adfdemo.view.faces.composite;

import oracle.adfinternal.view.faces.taglib.UIXEditableValueTag;


/**
 * NOTE: a clients may not extend UIXEditableValueTag (or
 * any other tag classes), as these are not part of the public
 * API (note the package);  I'm doing it for expedience here.
 */
public class DateFieldTag extends UIXEditableValueTag
{
  public String getComponentType()
  {
    return "oracle.adfdemo.DateField";
  }

  public String getRendererType()
  {
    return null;
  }
}
