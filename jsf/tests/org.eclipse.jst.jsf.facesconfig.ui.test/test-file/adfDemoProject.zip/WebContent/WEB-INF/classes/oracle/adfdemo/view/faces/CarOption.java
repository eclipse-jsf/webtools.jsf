package oracle.adfdemo.view.faces;

public class CarOption
{
  public CarOption(String name, int price)
  {
    _name = name;
    _price = price;
  }

  public String getName()
  {
    return _name;
  }

  public int getPrice()
  {
    return _price;
  }

  private final String _name;
  private final int _price;
}