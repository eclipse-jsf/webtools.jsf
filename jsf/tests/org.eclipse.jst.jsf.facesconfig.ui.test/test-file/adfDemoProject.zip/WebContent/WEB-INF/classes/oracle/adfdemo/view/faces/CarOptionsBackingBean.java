package oracle.adfdemo.view.faces;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import oracle.adf.view.faces.context.AdfFacesContext;


public class CarOptionsBackingBean
{
  public List getOptions() { return _options; }
  public void setOptions(List options) { _options = options; }

  public String pickOptions()
  {
    List options = getOptions();
    List realOptionObjects = new ArrayList();
    for (int i = 0; i < _AVAILABLE_OPTIONS.length; i++)
    {
      if (options.contains("" + i))
        realOptionObjects.add(_AVAILABLE_OPTIONS[i]);
    }

    AdfFacesContext.getCurrentInstance().returnFromDialog(realOptionObjects,
                                                          null);
    return null;
  }

  public List getOptionsItems()
  {
    return _OPTIONS_ITEMS;
  }

  private List _options;

  static private final List _OPTIONS_ITEMS = new ArrayList();

  static private final CarOption[] _AVAILABLE_OPTIONS =
  {
    new CarOption("Power windows", 350),
    new CarOption("Automatic transmission", 990),
    new CarOption("Side-curtain air bags", 600)
  };

  static
  {
    _OPTIONS_ITEMS.add(new SelectItem("0",
                                      "Power windows ($350)"));
    _OPTIONS_ITEMS.add(new SelectItem("1",
                                      "Automatic transmission ($990)"));
    _OPTIONS_ITEMS.add(new SelectItem("2",
                                      "Side-curtain air-bags ($600)"));

  }
}