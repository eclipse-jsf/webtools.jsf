package oracle.adfdemo.view.faces;

import oracle.adf.view.faces.event.DisclosureEvent;

public class ToggleBean implements java.io.Serializable
{
  public void onDisclosure(DisclosureEvent event)
  {
    _totalCount++;
  }

  public int getTotalCount()
  {
    return _totalCount;
  }

  private int _totalCount;
}
