package oracle.adfdemo.view.faces;



public class ActionBean

{

  public String nothing()

  {

    System.out.println("I AIN'T DOIN' NOTHIN'!");

    return null;

  }

  public String app1()
  {
    return "app1";
  }

  public String app2()
  {
    return "app2";
  }

}

