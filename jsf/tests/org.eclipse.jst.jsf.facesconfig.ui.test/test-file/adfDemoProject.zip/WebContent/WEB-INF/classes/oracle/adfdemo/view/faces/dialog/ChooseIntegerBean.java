package oracle.adfdemo.view.faces.dialog;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import oracle.adf.view.faces.context.AdfFacesContext;
import oracle.adf.view.faces.event.ReturnEvent;

public class ChooseIntegerBean
{
  public Integer getValue1()
  {
    return _value1;
  }

  public void setValue1(Integer value1)
  {
    _value1 = value1;
  }

  public Integer getValue2()
  {
    return _value2;
  }

  public void setValue2(Integer value2)
  {
    _value2 = value2;
  }

  public void sayHello(ReturnEvent event)
  {
    FacesMessage message = new FacesMessage("Hello!");
    FacesContext.getCurrentInstance().addMessage(null, message);
  }

  public String cancel()
  {
    AdfFacesContext.getCurrentInstance().returnFromDialog(null, null);
    return null;
  }

  public String select()
  {
    Integer value = new Integer(getValue1().intValue() +
                                getValue2().intValue());
    AdfFacesContext.getCurrentInstance().returnFromDialog(value, null);
    return null;
  }


  private Integer _value1;
  private Integer _value2;
}
