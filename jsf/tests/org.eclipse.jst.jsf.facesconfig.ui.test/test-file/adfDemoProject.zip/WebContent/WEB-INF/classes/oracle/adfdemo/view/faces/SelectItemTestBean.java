package oracle.adfdemo.view.faces;

import javax.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.HashMap;

public class SelectItemTestBean
{
  public SelectItemTestBean()
  {
    _oneItem = new SelectItem("foo", "Foo", "Description of foo", false);

    _itemList = new ArrayList();
    _itemList.add(new SelectItem("foo", "Foo", "Description of foo", false));
    _itemList.add(new SelectItem("bar", "Bar", "Description of bar", false));
    _itemList.add(new SelectItem("baz", "Baz", "Description of baz", false));

    _itemArray = new SelectItem[3];
    _itemArray[0] = new SelectItem("foo", "Foo", "Description of foo", false);
    _itemArray[1] = new SelectItem("bar", "Bar", "Description of bar", false);
    _itemArray[2] = new SelectItem("baz", "Baz", "Description of baz", false);

    _itemMap = new HashMap();
    _itemMap.put("Foo", "foo");
    _itemMap.put("Bar", "bar");
    _itemMap.put("Baz", "baz");
  }

  public SelectItem getOneItem()
  {
    return _oneItem;
  }

  public ArrayList getItemList()
  {
    return _itemList;
  }

  public HashMap getItemMap()
  {
    return _itemMap;
  }

  public SelectItem[] getItemArray()
  {
    return _itemArray;
  }

  private SelectItem _oneItem;
  private ArrayList  _itemList;
  private HashMap    _itemMap;
  private SelectItem[] _itemArray;
}
