package oracle.adfdemo.view.faces.email.resource;


import java.util.ListResourceBundle;

public class EmailDemoBundle extends ListResourceBundle
{
  public Object[][] getContents()
  {
    return _CONTENTS;
  }

  static private final Object[][] _CONTENTS =
  {
    {"TODAY_MASK", "Today, {0}"},
    {"EMAIL_LIST_ERROR", "Illegal email address."},
    {"EMAIL_LIST_ERROR_detail", "{0} is not a legal email address."},
    {"MESSAGE_SENT", "The message was sent successfully."},
    {"COULD_NOT_DELETE", "Deletion failed."},
    {"COULD_NOT_DELETE_detail", "The server returned an error: {0}."},
    {"EMAIL_DEMO_TITLE", "ADF Faces Email Demo"},   

    
  };
}

