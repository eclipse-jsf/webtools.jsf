package oracle.adfdemo.view.faces;

public class ConverterValidatorBean 
{
  public ConverterValidatorBean()
  {    
  }
  
  public Number getCurrencyValue()
  {
    return _currencyValue;
  }
  
  public void setCurrencyValue(Number value)
  {
    _currencyValue = value;
  }
  
  public Number getIntegerOnlyValue()
  {
    return _intOnlyValue;
  }
    
  public void setIntegerOnlyValue(Number value)
  {
    _intOnlyValue =  value;
  }
  
  public void setPercentValue(Number value)
  {
    _percentValue = value;
  }
  
  public Number getPercentValue()
  {
    return _percentValue;
  }
  
  public Number getGroupValue()
  {
    return _groupValue;
  }
  
  public void setGroupValue(Number value)
  {
    _groupValue = value;
  }
  
  private Number _currencyValue = new Double(78.57);
  
  private Number _intOnlyValue = new Double(99.99);
  
  private Number _percentValue = new Double(0.55);
  
  private Number _groupValue   = new Double(77777.89);
}
