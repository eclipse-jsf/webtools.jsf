/*
** Copyright (c) Oracle Corporation 2003-2004. All Rights Reserved.
*/
package oracle.adfdemo.view.faces.convertValidate;

import javax.faces.convert.Converter;
import javax.faces.webapp.ConverterTag;

import javax.servlet.jsp.JspException;


public class ConvertSSNTag extends ConverterTag
{

  public ConvertSSNTag()
  {
  }

  public int doStartTag() throws JspException
  {
    super.setConverterId(SSNConverter.CONVERTER_ID);
    return super.doStartTag();
  }

  /**
   * 
   */
  protected Converter createConverter() throws JspException
  {
    SSNConverter converter =
                              (SSNConverter)super.createConverter();
    return converter;
  }



}
