package oracle.adfdemo.view.faces.menu;
import java.util.List;
import oracle.adf.view.faces.component.core.nav.CoreCommandMenuItem;


public class DemoMenuItem 
{
  public DemoMenuItem()
  {}
  
  
  public void setLabel(String label)
  {
    _label = label;
  }  
  
  public String getLabel()
  {
    return _label;
  }

  public void setOutcome(String outcome)
  {
    _outcome = outcome;
  }  
  
  public String getOutcome()
  {
    return _outcome;
  }

  public void setViewId(String viewId)
  {
    _viewId = viewId;
  }  
  
  public String getViewId()
  {
    return _viewId;
  }
  
  // calling this 'ico' instead of 'icon' due to tree bug 
  public void setIco(String icon)
  {
    _icon = icon;
  }  
  
  // calling this 'ico' instead of 'icon' due to tree bug 
  public String getIco()
  {
    return _icon;
  }


  public void setType(String type)
  {
    _type = type;
  }  
  
  public String getType()
  {
    return _type;
  }
  

  public void setDestination(String destination)
  {
    _destination = destination;
  }  
  
  public String getDestination()
  {
    return _destination;
  }  
    
  public List getChildren()
  {
    return _children;
  }
  
  public void setChildren(List children)
  {
    _children = children;
  }  
  
  
  
  
  private String _label       = null;
  private String _outcome     = null;
  private String _viewId      = null;
  private String _destination = null;
  private String _icon        = null;
  private String _type        = CoreCommandMenuItem.TYPE_DEFAULT;
  private List   _children    = null;



}