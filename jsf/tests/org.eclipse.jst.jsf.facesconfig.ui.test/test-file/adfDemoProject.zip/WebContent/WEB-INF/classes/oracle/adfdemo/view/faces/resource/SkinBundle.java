package oracle.adfdemo.view.faces.resource;


import java.util.ListResourceBundle;

public class SkinBundle extends ListResourceBundle
{
  public Object[][] getContents()
  {
    return _CONTENTS;
  }

  static private final Object[][] _CONTENTS =
  {
    {"af_tableSelectMany.SELECT_COLUMN_HEADER", "Select A Lot"},
    {"af_tableSelectOne.SELECT_COLUMN_HEADER", "Select Just One"},
  };
}

