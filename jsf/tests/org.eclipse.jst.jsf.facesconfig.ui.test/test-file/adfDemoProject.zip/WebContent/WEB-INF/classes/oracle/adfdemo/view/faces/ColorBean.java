package oracle.adfdemo.view.faces;

import java.awt.Color;

import java.util.ArrayList;
import java.util.List;

/**
 * Managed bean for color component demos.
 * @version $Name:  $ ($Revision: 1.2 $) $Date: 2004/07/30 00:40:29 $
 */
public class ColorBean implements java.io.Serializable
{
  public Color getColorValue1()
  {
    return _colorValue1;
  }

  public void setColorValue1(Color colorValue)
  {
    _colorValue1 = colorValue;
  }

  public Color getColorValue2()
  {
    return _colorValue2;
  }

  public void setColorValue2(Color colorValue)
  {
    _colorValue2 = colorValue;
  }

  public Color getColorValue3()
  {
    return _colorValue3;
  }

  public void setColorValue3(Color colorValue)
  {
    _colorValue3 = colorValue;
  }

  public Color getColorValue4()
  {
    return _colorValue4;
  }

  public void setColorValue4(Color colorValue)
  {
    _colorValue4 = colorValue;
  }

  public Color[] getColorArray()
  {
    Color[] colorArray = new Color[4];
    colorArray[0] = _colorValue1;
    colorArray[1] = _colorValue2;
    colorArray[2] = _colorValue3;
    colorArray[3] = _colorValue4;
    return colorArray;
  }

  public List getColorList()
  {
    List colorList = new ArrayList();
    colorList.add(_colorValue3);
    colorList.add(_colorValue1);
    colorList.add(_colorValue4);
    colorList.add(_colorValue2);
    return colorList;
  }

  private Color _colorValue1 = new Color(255, 0, 0);
  private Color _colorValue2 = new Color(0, 255, 0);
  private Color _colorValue3 = new Color(0, 0, 255);
  private Color _colorValue4 = new Color(255, 255, 0);

}
