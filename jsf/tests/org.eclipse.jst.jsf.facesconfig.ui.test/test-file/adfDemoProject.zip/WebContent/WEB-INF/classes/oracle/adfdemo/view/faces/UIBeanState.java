package oracle.adfdemo.view.faces;

public class UIBeanState implements java.io.Serializable
{
  public UIBeanState()
  {
  }

  public boolean isTitleSet()
  {
    return _isTitleSet;
  }

  public void setTitleSet(boolean set)
  {
    _isTitleSet = set;
  }

  private boolean _isTitleSet;
}
