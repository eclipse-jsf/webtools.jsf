package oracle.adfdemo.view.faces.survey;

import javax.faces.webapp.ValidatorTag;
import javax.faces.validator.Validator;
import javax.servlet.jsp.JspException;

public class AnswerValidatorTag extends ValidatorTag
{

  private String _questionIndex = "";
  private final String ID = "survey answer validator";

  public AnswerValidatorTag()
  {
      super();
      super.setValidatorId(ID);
  }

  public void setQuestionIndex(String index)
  {
    _questionIndex = index;
  }

  public String getQuestionIndex()
  {
    return _questionIndex;
  }

  protected Validator createValidator() throws JspException {

      AnswerValidator validator = (AnswerValidator)super.createValidator();
      validator.setQuestionIndex(_questionIndex);

      //System.out.println("just instantiated " + validator + " with: " + validator.getQuestionIndex());
      return validator;

  }


} // end AnswerValidatorTag