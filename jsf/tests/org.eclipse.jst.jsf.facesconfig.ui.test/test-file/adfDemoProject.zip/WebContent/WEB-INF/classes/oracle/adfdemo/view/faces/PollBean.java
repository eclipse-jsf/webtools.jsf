/*
** Copyright (c) Oracle Corporation 2004. All Rights Reserved.
**
**345678901234567890123456789012345678901234567890123456789012345678901234567890
*/
package oracle.adfdemo.view.faces;
import javax.faces.event.ActionEvent;
import oracle.adf.view.faces.event.PollEvent;

/**
 * Bean for poll component demos.
 *
 * @version $Name:  $ ($Revision: 1.5 $) $Date: 2004/07/30 20:41:51 $
 */

public class PollBean implements java.io.Serializable
{
  public PollBean()
  {
    _POLL_COUNT = 0;
  }
  
  public void onPoll(PollEvent event)
  {
    ++_POLL_COUNT;
  }
  
  public int getPollCount()
  {
    return _POLL_COUNT;
  }
  
  public void resetPoll(ActionEvent event)
  {
    _POLL_COUNT = 0;
  }
  
  private static int _POLL_COUNT;
}
