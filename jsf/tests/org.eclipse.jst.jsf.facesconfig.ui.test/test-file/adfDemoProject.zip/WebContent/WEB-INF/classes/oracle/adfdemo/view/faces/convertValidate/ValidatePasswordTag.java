/*
** Copyright (c) Oracle Corporation 2005. All Rights Reserved.
*/
package oracle.adfdemo.view.faces.convertValidate;


import javax.faces.validator.Validator;
import javax.faces.webapp.ValidatorTag;
import javax.servlet.jsp.JspException;


public class ValidatePasswordTag extends ValidatorTag
{

  public ValidatePasswordTag()
  {
  }

  public int doStartTag() throws JspException
  {
    super.setValidatorId(PasswordValidator.VALIDATOR_ID);
    return super.doStartTag();
  }

  /**
   * 
   */
  protected Validator createValidator() throws JspException
  {
    PasswordValidator validator =
                              (PasswordValidator)super.createValidator();
    return validator;
  }



}
