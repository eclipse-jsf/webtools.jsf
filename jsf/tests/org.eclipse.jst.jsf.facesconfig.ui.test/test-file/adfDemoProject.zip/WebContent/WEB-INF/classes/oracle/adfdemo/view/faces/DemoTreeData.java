
package oracle.adfdemo.view.faces;

import java.util.ArrayList;

/**
 *
 * @version $Name:  $ ($Revision: 1.2 $) $Date: 2004/07/30 00:40:30 $
 * @author ADF Faces Team
 */

public class DemoTreeData extends ArrayList
{

  // data

  /**
   * @param text the text label of the tree node
   */
  private static TreeNodeImpl _createNode(
    String text
    )
  {
    TreeNodeImpl data = new TreeNodeImpl();
    data.setText(text);
    data.setDestination( "http://www.oracle.com");
    return data;
  }

  public DemoTreeData()
  {
    TreeNodeImpl node_0 = _createNode("node_0");
    TreeNodeImpl node_0_0 = _createNode("node_0_0");
    TreeNodeImpl node_0_0_0 = _createNode("node_0_0_0");
    TreeNodeImpl node_0_0_0_0 = _createNode("node_0_0_0_0");
    TreeNodeImpl node_0_0_1 = _createNode("node_0_0_1");
    TreeNodeImpl node_0_1 = _createNode("node_0_1");
    TreeNodeImpl node_0_1_0 = _createNode("node_0_1_0");
    TreeNodeImpl node_0_1_1 = _createNode("node_0_1_1");
    TreeNodeImpl node_0_2 = _createNode("node_0_2");
    TreeNodeImpl node_0_3 = _createNode("node_0_3");
    TreeNodeImpl node_0_4 = _createNode("node_0_4");
    TreeNodeImpl node_0_5 = _createNode("node_0_5");

    add(node_0);

    ArrayList list_0 = new ArrayList();
    list_0.add(node_0_0);
    list_0.add(node_0_1);
    list_0.add(node_0_2);
    list_0.add(node_0_3);
    list_0.add(node_0_4);
    list_0.add(node_0_5);
    node_0.setChildren(list_0);

    ArrayList list_0_0 = new ArrayList();
    list_0_0.add(node_0_0_0);
    list_0_0.add(node_0_0_1);
    node_0_0.setChildren(list_0_0);

    ArrayList list_0_0_0 = new ArrayList();
    list_0_0_0.add(node_0_0_0_0);
    node_0_0_0.setChildren(list_0_0_0);

    ArrayList list_0_1 = new ArrayList();
    list_0_1.add(node_0_1_0);
    list_0_1.add(node_0_1_1);
    node_0_1.setChildren(list_0_1);
  }
}
