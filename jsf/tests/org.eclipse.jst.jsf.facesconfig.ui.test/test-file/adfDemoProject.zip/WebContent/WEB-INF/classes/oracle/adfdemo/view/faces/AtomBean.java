package oracle.adfdemo.view.faces;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

public class AtomBean implements java.io.Serializable
{
  String name;
  String symbol;
  int number;
  String group;

  public String action()
  {
    FacesContext context = FacesContext.getCurrentInstance();
    FacesMessage message = new FacesMessage("Clicked on Chemical " + getName());
    context.addMessage(null, message);
    return null;
  }

  public AtomBean()
  {
  }

  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public String getSymbol()
  {
    return symbol;
  }

  public void setSymbol(String symbol)
  {
    this.symbol = symbol;
  }

  public int getNumber()
  {
    return number;
  }

  public void setNumber(int number)
  {
    this.number = number;
  }

  public String getGroup()
  {
    return group;
  }

  public void setGroup(String group)
  {
    this.group = group;
  }
  
  
}
