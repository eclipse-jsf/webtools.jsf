package beans;

import java.util.HashMap;
import java.util.List;

public class MyBean {
	
	private List<HashMap<String, MyBean2>> myList;
	public List<HashMap<String, MyBean2>> getMyList() {
		return myList;
	}

	public void setMyList(List<HashMap<String, MyBean2>> myList) {
		this.myList = myList;
	}

}
